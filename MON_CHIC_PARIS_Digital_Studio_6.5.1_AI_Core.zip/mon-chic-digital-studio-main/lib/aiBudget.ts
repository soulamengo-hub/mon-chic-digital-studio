import { getSupabaseConfig } from './supabaseRest';

export type AiUsageSummary = {
  budgetEur: number;
  spentEur: number;
  remainingEur: number;
  percent: number;
  warning: boolean;
  blocked: boolean;
};

function serviceHeaders(extra: Record<string, string> = {}) {
  const { key } = getSupabaseConfig();
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || key;
  return {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

export function getAiBudgetEur() {
  const value = Number(process.env.AI_MONTHLY_BUDGET_EUR || '25');
  return Number.isFinite(value) && value > 0 ? value : 25;
}

export async function getMonthlyAiSpend(): Promise<number> {
  const { url } = getSupabaseConfig();
  const start = new Date();
  start.setUTCDate(1);
  start.setUTCHours(0, 0, 0, 0);
  const endpoint = `${url}/rest/v1/ai_usage?select=estimated_cost_eur&created_at=gte.${encodeURIComponent(start.toISOString())}`;
  const response = await fetch(endpoint, { headers: serviceHeaders(), cache: 'no-store' });
  if (!response.ok) {
    // The AI feature may be tested before the migration is installed. In that case,
    // do not silently claim a reliable spend value.
    throw new Error('KI-Kostenprotokoll ist noch nicht eingerichtet. Bitte die Migration supabase/migration_6_5_ai_usage.sql ausführen.');
  }
  const rows = await response.json() as Array<{ estimated_cost_eur?: number | string }>;
  return rows.reduce((sum, row) => sum + Number(row.estimated_cost_eur || 0), 0);
}

export async function getAiUsageSummary(): Promise<AiUsageSummary> {
  const budgetEur = getAiBudgetEur();
  const spentEur = await getMonthlyAiSpend();
  const remainingEur = Math.max(0, budgetEur - spentEur);
  const percent = Math.min(100, (spentEur / budgetEur) * 100);
  return {
    budgetEur,
    spentEur,
    remainingEur,
    percent,
    warning: percent >= 80,
    blocked: spentEur >= budgetEur,
  };
}

export async function logAiUsage(input: {
  feature: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  estimatedCostEur: number;
  status: 'success' | 'error' | 'blocked';
  metadata?: Record<string, unknown>;
}) {
  const { url } = getSupabaseConfig();
  const response = await fetch(`${url}/rest/v1/ai_usage`, {
    method: 'POST',
    headers: serviceHeaders({ Prefer: 'return=minimal' }),
    body: JSON.stringify({
      feature: input.feature,
      model: input.model,
      input_tokens: input.inputTokens,
      output_tokens: input.outputTokens,
      estimated_cost_eur: Number(input.estimatedCostEur.toFixed(6)),
      status: input.status,
      metadata: input.metadata || {},
    }),
    cache: 'no-store',
  });
  if (!response.ok) throw new Error(`KI-Kosten konnten nicht protokolliert werden: ${await response.text()}`);
}

export function estimateOpenAiCostEur(model: string, inputTokens: number, outputTokens: number) {
  // Defaults for gpt-4.1-mini; configurable so pricing can be updated without code changes.
  const inputUsdPerMillion = Number(process.env.OPENAI_INPUT_USD_PER_1M || (model.includes('gpt-4.1-mini') ? '0.40' : '0.40'));
  const outputUsdPerMillion = Number(process.env.OPENAI_OUTPUT_USD_PER_1M || (model.includes('gpt-4.1-mini') ? '1.60' : '1.60'));
  const usdToEur = Number(process.env.OPENAI_USD_TO_EUR || '0.92');
  const usd = (inputTokens / 1_000_000) * inputUsdPerMillion + (outputTokens / 1_000_000) * outputUsdPerMillion;
  return usd * usdToEur;
}
