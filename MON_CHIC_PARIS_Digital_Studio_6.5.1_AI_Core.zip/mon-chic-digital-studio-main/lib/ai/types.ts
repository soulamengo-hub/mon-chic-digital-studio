export type ConfidenceMap = Record<string, number>;

export type ArticleAnalysis = {
  brand?: string;
  category?: string;
  subcategory?: string;
  color?: string;
  secondary_color?: string;
  material?: string;
  pattern?: string;
  condition?: string;
  era?: string;
  style_key?: string;
  occasions?: string[];
  public_title?: string;
  public_description?: string;
  notes?: string;
  confidence?: ConfidenceMap;
};

export type AiProviderUsage = {
  inputTokens: number;
  outputTokens: number;
};

export type AiProviderResult = {
  text: string;
  usage: AiProviderUsage;
  provider: string;
  model: string;
};

export type ArticleImageAnalysisInput = {
  imageDataUrl: string;
};
