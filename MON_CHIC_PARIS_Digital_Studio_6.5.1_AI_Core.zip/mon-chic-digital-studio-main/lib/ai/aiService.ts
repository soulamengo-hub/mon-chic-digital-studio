import { buildArticleImageAnalysisPrompt } from './promptEngine';
import { analyzeImageWithOpenAi } from './openAiProvider';
import { validateArticleAnalysis } from './validator';
import type { ArticleImageAnalysisInput } from './types';

export async function analyzeArticleImage(input: ArticleImageAnalysisInput) {
  if (!input.imageDataUrl?.startsWith('data:image/')) throw new Error('Für die Analyse wird ein Bild benötigt.');
  if (input.imageDataUrl.length > 3_500_000) throw new Error('Das Analysebild ist zu groß.');

  const providerResult = await analyzeImageWithOpenAi({
    imageDataUrl: input.imageDataUrl,
    prompt: buildArticleImageAnalysisPrompt(),
  });

  return {
    analysis: validateArticleAnalysis(providerResult.text),
    usage: providerResult.usage,
    provider: providerResult.provider,
    model: providerResult.model,
  };
}
