import { NextResponse } from 'next/server';
import { analyzeArticleImage } from '@/lib/ai';
import { estimateOpenAiCostEur, getAiUsageSummary, logAiUsage } from '@/lib/aiBudget';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  const configuredModel = process.env.OPENAI_MODEL || 'gpt-4.1-mini';
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'OPENAI_API_KEY ist in Vercel noch nicht eingerichtet.' }, { status: 503 });
    }

    const budgetBefore = await getAiUsageSummary();
    if (budgetBefore.blocked || budgetBefore.remainingEur < 0.02) {
      await logAiUsage({
        feature: 'article_image_analysis', model: configuredModel, inputTokens: 0, outputTokens: 0,
        estimatedCostEur: 0, status: 'blocked', metadata: { provider: 'openai', architecture: 'mon_chic_ai_service_v1' },
      });
      return NextResponse.json({
        error: `Das monatliche KI-Budget von ${budgetBefore.budgetEur.toFixed(2)} € ist erreicht.`,
        budget: budgetBefore,
      }, { status: 402 });
    }

    const body = await request.json() as { imageDataUrl?: string };
    if (!body.imageDataUrl?.startsWith('data:image/')) {
      return NextResponse.json({ error: 'Für die Analyse wird ein Bild benötigt.' }, { status: 400 });
    }
    if (body.imageDataUrl.length > 3_500_000) {
      return NextResponse.json({ error: 'Das Analysebild ist zu groß.' }, { status: 413 });
    }

    const result = await analyzeArticleImage({ imageDataUrl: body.imageDataUrl });
    const estimatedCostEur = estimateOpenAiCostEur(result.model, result.usage.inputTokens, result.usage.outputTokens);

    await logAiUsage({
      feature: 'article_image_analysis',
      model: result.model,
      inputTokens: result.usage.inputTokens,
      outputTokens: result.usage.outputTokens,
      estimatedCostEur,
      status: 'success',
      metadata: { provider: result.provider, architecture: 'mon_chic_ai_service_v1' },
    });

    const budget = await getAiUsageSummary();
    return NextResponse.json({
      analysis: result.analysis,
      usage: { ...result.usage, estimatedCostEur },
      budget,
      ai: { provider: result.provider, model: result.model, serviceVersion: '1.0' },
    });
  } catch (error) {
    const status = typeof error === 'object' && error && 'status' in error && typeof error.status === 'number' ? error.status : 500;
    try {
      await logAiUsage({
        feature: 'article_image_analysis', model: configuredModel, inputTokens: 0, outputTokens: 0,
        estimatedCostEur: 0, status: 'error', metadata: { architecture: 'mon_chic_ai_service_v1', status },
      });
    } catch {
      // The original error is more useful than a secondary logging failure.
    }
    return NextResponse.json({ error: error instanceof Error ? error.message : 'KI-Analyse fehlgeschlagen.' }, { status });
  }
}
