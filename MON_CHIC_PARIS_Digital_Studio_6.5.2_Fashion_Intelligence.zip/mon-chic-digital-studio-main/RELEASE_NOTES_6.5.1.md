# MON CHIC PARIS Digital Studio 6.5.1

## Mon Chic AI Core

Diese Version entkoppelt die Artikelerkennung von der API-Route und führt eine eigene, austauschbare KI-Architektur ein.

### Neu

- `lib/ai/aiService.ts`: zentraler Mon Chic AI Service
- `lib/ai/openAiProvider.ts`: OpenAI als austauschbarer Provider
- `lib/ai/knowledgeBase.ts`: kuratierte Stammdaten für Kategorien, Designer, Farben, Materialien, Muster, Zustände, Stile, Anlässe und Epochen
- `lib/ai/promptEngine.ts`: verbindliche Prompt-Regeln gegen erfundene Marken und ungesicherte Aussagen
- `lib/ai/validator.ts`: serverseitige Prüfung und Bereinigung aller KI-Vorschläge
- strukturierte Provider- und Service-Metadaten im Kostenprotokoll
- Health-Version 6.5.1
- verständlicher Button „Artikel erkennen“

### Sicherheitsprinzipien

- KI schreibt weiterhin nie direkt in `products`.
- Nicht erlaubte Katalogwerte werden verworfen.
- Marken werden nur aus der kuratierten Liste akzeptiert.
- Größe, Echtheit und Preis bleiben ausdrücklich ausgeschlossen.
- Alle Vorschläge müssen durch den Benutzer übernommen und vor dem Speichern geprüft werden.

### Konfiguration

Bestehende Variablen bleiben gültig:

- `OPENAI_API_KEY`
- `OPENAI_MODEL` (optional, Standard `gpt-4.1-mini`)
- `AI_MONTHLY_BUDGET_EUR` (optional, Standard `25`)
- Supabase-Konfiguration und `SUPABASE_SERVICE_ROLE_KEY`

Es ist keine neue Datenbankmigration gegenüber 6.5.0 erforderlich.
