# MON CHIC PARIS Digital Studio 6.5.2

## Fashion Intelligence Engine 2.0

- analysiert bis zu sieben Fotos eines Artikels gemeinsam
- priorisiert Marken-, Größen- und Materialetiketten vor visuellen Vermutungen
- blockiert MON CHIC / MON CHIC PARIS ausdrücklich als Produktmarke
- erweiterte Marken-Knowledge-Base, unter anderem H&M, Zara, Mango, COS und Massimo Dutti
- erkennt Originalgröße, Größensystem, internationale Größe und sichtbare Materialzusammensetzungen
- Etikettinformationen haben Vorrang vor Bildschätzungen
- neue Vorschläge für Saison und Größenfelder
- „Alle übernehmen“ erzeugt nach erkannter Unterkategorie automatisch eine SKU
- einzelne Übernahme der Unterkategorie erzeugt ebenfalls automatisch eine SKU
- Kostenprotokoll enthält Anzahl analysierter Bilder und Fashion-Intelligence-Version
- Health-Version 6.5.2

## Datenbank

Keine neue Supabase-Migration erforderlich. Die Migration `migration_6_5_ai_usage.sql` bleibt gültig.

## Testschwerpunkte

1. Gesamtansicht und Etikettfotos gemeinsam hochladen.
2. „Alle Fotos analysieren“ starten.
3. Marke, Größe, Material, Kategorie und Unterkategorie prüfen.
4. Vorschläge übernehmen und automatische SKU kontrollieren.
5. Artikel erst nach manueller Prüfung speichern.
