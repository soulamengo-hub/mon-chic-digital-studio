-- MON CHIC PARIS Digital Studio 6.5.0
-- KI-Nutzungsprotokoll und monatliche Kostenkontrolle

create table if not exists public.ai_usage (
  id uuid primary key default gen_random_uuid(),
  feature text not null,
  model text not null,
  input_tokens integer not null default 0 check (input_tokens >= 0),
  output_tokens integer not null default 0 check (output_tokens >= 0),
  estimated_cost_eur numeric(12,6) not null default 0 check (estimated_cost_eur >= 0),
  status text not null default 'success' check (status in ('success','error','blocked')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists ai_usage_created_at_idx on public.ai_usage (created_at desc);
create index if not exists ai_usage_feature_idx on public.ai_usage (feature);

alter table public.ai_usage enable row level security;
-- No browser policy: reads/writes are performed server-side. Use SUPABASE_SERVICE_ROLE_KEY in Vercel.
