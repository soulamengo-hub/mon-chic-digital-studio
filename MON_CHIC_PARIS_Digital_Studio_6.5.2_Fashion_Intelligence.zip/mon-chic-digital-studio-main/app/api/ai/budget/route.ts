import { NextResponse } from 'next/server';
import { getAiUsageSummary } from '@/lib/aiBudget';

export const runtime = 'nodejs';

export async function GET() {
  try {
    return NextResponse.json(await getAiUsageSummary());
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'KI-Budget konnte nicht geladen werden.' }, { status: 500 });
  }
}
