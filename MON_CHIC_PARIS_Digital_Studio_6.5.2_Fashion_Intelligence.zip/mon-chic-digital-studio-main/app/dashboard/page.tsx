export { default } from '../page';
