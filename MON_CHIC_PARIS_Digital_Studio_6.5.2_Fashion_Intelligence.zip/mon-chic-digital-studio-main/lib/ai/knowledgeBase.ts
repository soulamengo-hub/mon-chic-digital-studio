import { categories, designerSuggestions } from '@/lib/catalog';

const commonFashionBrands = [
  'H&M','Zara','Mango','COS','Massimo Dutti','& Other Stories','Arket','Uniqlo','Esprit',
  'Marc O’Polo','Tommy Hilfiger','Ralph Lauren','Lacoste','Levi’s','Gant','Guess','Michael Kors',
  'Sandro','Maje','Sézane','Claudie Pierlot','Ba&sh','Reiss','Hugo Boss','Max Mara Weekend',
];

export const articleKnowledgeBase = {
  categories,
  brands: [...new Set([...designerSuggestions, ...commonFashionBrands])].sort((a, b) => a.localeCompare(b, 'de')),
  forbiddenBrands: ['MON CHIC', 'MON CHIC PARIS', 'Mon Chic', 'Mon Chic Paris'],
  colors: [
    'Schwarz','Weiß','Creme','Beige','Braun','Grau','Blau','Marineblau','Rot','Bordeaux',
    'Rosa','Lila','Grün','Gelb','Orange','Gold','Silber','Mehrfarbig',
  ],
  materials: [
    'Baumwolle','Wolle','Kaschmir','Seide','Leinen','Leder','Lammleder','Wildleder',
    'Viskose','Polyester','Polyamid','Elasthan','Denim','Samt','Tweed','Spitze','Pelz','Kunstpelz',
  ],
  patterns: ['Uni','Blumen','Karo','Streifen','Punkte','Animal Print','Geometrisch','Batik','Paisley','Sonstiges'],
  conditions: ['Neu mit Etikett','Neuwertig','Sehr gut','Gut','Akzeptabel'],
  styles: ['Parisian Classic','Quiet Elegance','Boho Romantic','Vintage Floral','Rock Chic','Casual Sport','Minimalist','Preppy Academia','Evening Glam'],
  occasions: [
    'Business','Casual','Chic','Abendgarderobe','Cocktail','Hochzeit','Dinner','Urlaub',
    'Strand','Skiurlaub','Sportiv','Outdoor','Trauerfeier','Religiöse Feier','Weihnachten','Silvester',
  ],
  eras: ['Zeitlos','1950er','1960er','1970er','1980er','1990er','2000er','Y2K','Unbekannt'],
  seasons: ['Ganzjährig','Frühling','Sommer','Herbst','Winter'],
  sizeSystems: ['DE','FR','IT','UK','US','One Size'],
} as const;

export function formatKnowledgeBaseForPrompt() {
  const categoryText = Object.entries(articleKnowledgeBase.categories)
    .map(([category, values]) => `${category}: ${values.join(', ')}`)
    .join('\n');

  return [
    `Kategorien und Unterkategorien:\n${categoryText}`,
    `Bekannte Designer/Marken (nur bei klar sichtbarem Etikett oder Logo verwenden): ${articleKnowledgeBase.brands.join(', ')}`,
    `Verbotene Markenwerte: ${articleKnowledgeBase.forbiddenBrands.join(', ')}`,
    `Farben: ${articleKnowledgeBase.colors.join(', ')}`,
    `Materialien: ${articleKnowledgeBase.materials.join(', ')}`,
    `Muster: ${articleKnowledgeBase.patterns.join(', ')}`,
    `Zustände: ${articleKnowledgeBase.conditions.join(', ')}`,
    `Stile: ${articleKnowledgeBase.styles.join(', ')}`,
    `Anlässe: ${articleKnowledgeBase.occasions.join(', ')}`,
    `Epochen: ${articleKnowledgeBase.eras.join(', ')}`,
    `Saisons: ${articleKnowledgeBase.seasons.join(', ')}`,
    `Größensysteme: ${articleKnowledgeBase.sizeSystems.join(', ')}`,
  ].join('\n\n');
}
