import type { AiProviderResult } from './types';

function extractText(payload: any): string {
  if (typeof payload?.output_text === 'string') return payload.output_text;
  for (const item of payload?.output || []) {
    for (const content of item?.content || []) {
      if (typeof content?.text === 'string') return content.text;
    }
  }
  return '';
}

export async function analyzeImagesWithOpenAi(input: { imageDataUrls: string[]; prompt: string }): Promise<AiProviderResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error('OPENAI_API_KEY ist in Vercel noch nicht eingerichtet.');
  const model = process.env.OPENAI_MODEL || 'gpt-4.1-mini';

  const imageContent = input.imageDataUrls.map((imageUrl, index) => ([
    { type: 'input_text', text: `Bild ${index + 1} von ${input.imageDataUrls.length}` },
    { type: 'input_image', image_url: imageUrl, detail: index === 0 ? 'high' : 'low' },
  ])).flat();

  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      max_output_tokens: 1200,
      input: [{
        role: 'user',
        content: [
          { type: 'input_text', text: input.prompt },
          ...imageContent,
        ],
      }],
    }),
  });

  const payload = await response.json();
  if (!response.ok) {
    const error = new Error(payload?.error?.message || 'OpenAI-Analyse fehlgeschlagen.') as Error & { status?: number };
    error.status = response.status;
    throw error;
  }

  const text = extractText(payload);
  if (!text) throw new Error('Die KI hat keine auswertbare Antwort geliefert.');
  return {
    text,
    usage: {
      inputTokens: Number(payload?.usage?.input_tokens || 0),
      outputTokens: Number(payload?.usage?.output_tokens || 0),
    },
    provider: 'openai',
    model,
  };
}
