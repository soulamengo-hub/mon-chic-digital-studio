import { articleKnowledgeBase } from './knowledgeBase';
import type { ArticleAnalysis } from './types';

function cleanText(value: unknown, maxLength = 1000) {
  if (typeof value !== 'string') return undefined;
  const cleaned = value.trim().replace(/\s+/g, ' ');
  return cleaned ? cleaned.slice(0, maxLength) : undefined;
}

function canonicalAllowedValue(value: unknown, allowed: readonly string[]) {
  const cleaned = cleanText(value, 120);
  if (!cleaned) return undefined;
  const normalized = cleaned.toLocaleLowerCase('de-DE');
  return allowed.find(item => item.toLocaleLowerCase('de-DE') === normalized);
}

function parseJsonObject(text: string): Record<string, unknown> {
  const cleaned = text.trim().replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start < 0 || end < start) throw new Error('Die KI-Antwort enthielt kein gültiges JSON.');
  const parsed = JSON.parse(cleaned.slice(start, end + 1));
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('Die KI-Antwort hatte ein ungültiges Format.');
  return parsed as Record<string, unknown>;
}

export function validateArticleAnalysis(text: string): ArticleAnalysis {
  const raw = parseJsonObject(text);
  const category = canonicalAllowedValue(raw.category, Object.keys(articleKnowledgeBase.categories));
  const allowedSubcategories = category
    ? articleKnowledgeBase.categories[category as keyof typeof articleKnowledgeBase.categories]
    : [];
  const rawBrand = cleanText(raw.brand, 120);
  const brand = rawBrand && !articleKnowledgeBase.forbiddenBrands.some(item => item.toLowerCase() === rawBrand.toLowerCase())
    ? canonicalAllowedValue(rawBrand, articleKnowledgeBase.brands)
    : undefined;

  const result: ArticleAnalysis = {
    brand,
    category,
    subcategory: canonicalAllowedValue(raw.subcategory, allowedSubcategories),
    season: canonicalAllowedValue(raw.season, articleKnowledgeBase.seasons),
    original_size: cleanText(raw.original_size, 120),
    size_system: canonicalAllowedValue(raw.size_system, articleKnowledgeBase.sizeSystems),
    de_size: cleanText(raw.de_size, 40),
    international_size: cleanText(raw.international_size, 40),
    color: canonicalAllowedValue(raw.color, articleKnowledgeBase.colors),
    secondary_color: canonicalAllowedValue(raw.secondary_color, articleKnowledgeBase.colors),
    material: cleanText(raw.material, 240),
    pattern: canonicalAllowedValue(raw.pattern, articleKnowledgeBase.patterns),
    condition: canonicalAllowedValue(raw.condition, articleKnowledgeBase.conditions),
    era: canonicalAllowedValue(raw.era, articleKnowledgeBase.eras),
    style_key: canonicalAllowedValue(raw.style_key, articleKnowledgeBase.styles),
    public_title: cleanText(raw.public_title, 180),
    public_description: cleanText(raw.public_description, 1800),
    notes: cleanText(raw.notes, 600),
  };

  if (Array.isArray(raw.occasions)) {
    result.occasions = [...new Set(raw.occasions
      .map(value => canonicalAllowedValue(value, articleKnowledgeBase.occasions))
      .filter((value): value is string => Boolean(value)))];
  }

  if (raw.confidence && typeof raw.confidence === 'object' && !Array.isArray(raw.confidence)) {
    result.confidence = Object.fromEntries(
      Object.entries(raw.confidence as Record<string, unknown>)
        .filter(([key]) => key in result && result[key as keyof ArticleAnalysis] !== undefined)
        .map(([key, value]) => [key, Math.max(0, Math.min(1, Number(value) || 0))]),
    );
  }

  return Object.fromEntries(
    Object.entries(result).filter(([, value]) => value !== undefined && (!Array.isArray(value) || value.length > 0)),
  ) as ArticleAnalysis;
}
