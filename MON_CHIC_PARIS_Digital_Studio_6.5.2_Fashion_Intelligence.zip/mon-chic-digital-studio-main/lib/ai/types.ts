export type ConfidenceMap = Record<string, number>;

export type ArticleAnalysis = {
  brand?: string;
  category?: string;
  subcategory?: string;
  season?: string;
  original_size?: string;
  size_system?: string;
  de_size?: string;
  international_size?: string;
  color?: string;
  secondary_color?: string;
  material?: string;
  pattern?: string;
  condition?: string;
  era?: string;
  style_key?: string;
  occasions?: string[];
  public_title?: string;
  public_description?: string;
  notes?: string;
  confidence?: ConfidenceMap;
};

export type AiProviderUsage = {
  inputTokens: number;
  outputTokens: number;
};

export type AiProviderResult = {
  text: string;
  usage: AiProviderUsage;
  provider: string;
  model: string;
};

export type ArticleImageAnalysisInput = {
  imageDataUrls: string[];
};
