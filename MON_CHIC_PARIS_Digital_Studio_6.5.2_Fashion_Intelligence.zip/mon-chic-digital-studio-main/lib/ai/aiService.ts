import { buildArticleImageAnalysisPrompt } from './promptEngine';
import { analyzeImagesWithOpenAi } from './openAiProvider';
import { validateArticleAnalysis } from './validator';
import type { ArticleImageAnalysisInput } from './types';

export async function analyzeArticleImages(input: ArticleImageAnalysisInput) {
  const imageDataUrls = input.imageDataUrls?.filter(value => value?.startsWith('data:image/')).slice(0, 7) || [];
  if (!imageDataUrls.length) throw new Error('Für die Analyse wird mindestens ein Bild benötigt.');
  if (imageDataUrls.some(value => value.length > 3_500_000)) throw new Error('Mindestens ein Analysebild ist zu groß.');

  const providerResult = await analyzeImagesWithOpenAi({
    imageDataUrls,
    prompt: buildArticleImageAnalysisPrompt(imageDataUrls.length),
  });

  return {
    analysis: validateArticleAnalysis(providerResult.text),
    usage: providerResult.usage,
    provider: providerResult.provider,
    model: providerResult.model,
    imageCount: imageDataUrls.length,
  };
}
