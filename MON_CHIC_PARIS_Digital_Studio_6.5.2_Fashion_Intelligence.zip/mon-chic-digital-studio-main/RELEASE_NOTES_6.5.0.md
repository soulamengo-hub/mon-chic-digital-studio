# MON CHIC PARIS Digital Studio 6.5.0

## Mon Chic AI – Artikel-Assistent MVP

- KI-Bildanalyse direkt in der Artikelerfassung
- Vorschläge für Marke, Kategorie, Unterkategorie, Farbe, Material, Muster, Zustand, Epoche und Stil
- Entwurf für öffentlichen Titel und Produktbeschreibung
- Vorschläge werden zunächst separat angezeigt und niemals automatisch gespeichert
- Einzelne Vorschläge oder alle Vorschläge können bewusst übernommen werden
- Sicherheitswert (Confidence) pro Feld
- Größen, Preise, Echtheit und SKU bleiben ausdrücklich außerhalb der KI-Erkennung
- Kategorien und Unterkategorien werden gegen den festen MON-CHIC-Katalog validiert

## Kostenkontrolle

- Monatsbudget standardmäßig 25 EUR
- Kostenprotokoll pro KI-Aufruf
- Anzeige von Monatsverbrauch, Restbudget und Kosten der letzten Analyse
- Warnung ab 80 Prozent
- harte Sperre bei erreichtem Budget
- Preise und USD/EUR-Faktor über Umgebungsvariablen konfigurierbar

## Erforderliche Einrichtung

1. `supabase/migration_6_5_ai_usage.sql` im Supabase SQL Editor ausführen.
2. In Vercel setzen:
   - `OPENAI_API_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - optional `OPENAI_MODEL=gpt-4.1-mini`
   - optional `AI_MONTHLY_BUDGET_EUR=25`
   - optional `OPENAI_INPUT_USD_PER_1M=0.40`
   - optional `OPENAI_OUTPUT_USD_PER_1M=1.60`
   - optional `OPENAI_USD_TO_EUR=0.92`
3. Neu deployen.

## Prüfung

- `npm ci`: erfolgreich
- `npm run typecheck`: erfolgreich
- `npm run build`: erfolgreich
